# Agent 轨迹投毒侦探 · 学生实验包

这个包只有本地要用的文件，网页上的讲解、选择题和参考答案不用带下来。

## 包里有什么

| 路径 | 用途 |
| --- | --- |
| `code/practice1_starter.py` | 模块一练习：读出工具名称（带 TODO） |
| `code/practice2_starter.py` | 模块二练习：统计可疑步骤（带 TODO） |
| `code/challenge_starter.py` | 综合实验：审查 8 条轨迹（带 5 个 TODO） |
| `code/practice1_answer.py` | 练习 1 参考答案 |
| `code/practice2_answer.py` | 练习 2 参考答案 |
| `code/challenge_answer.py` | 综合实验参考答案 |
| `data/trajectories.json` | 8 条模拟轨迹 |
| `outputs/expected_output.txt` | 综合实验参考答案的运行结果 |

注意：`code/challenge_starter.py` 用 `Path(__file__).resolve().parent.parent / "data" / "trajectories.json"` 找数据，所以 `code/`、`data/`、`outputs/` 三层要保持现在的相对位置，不要单独把某个 .py 挪到别处运行。

## 怎么跑

先解压，在解压出来的目录里执行：

```powershell
python code/challenge_starter.py
```

补全 5 个 TODO 之后，输出应与 `outputs/expected_output.txt` 一致：

- 轨迹总数 8
- 可疑步骤数 5、可疑轨迹数 4
- 来源 A 比例 25.0%，来源 B 比例 75.0%

其他两个练习同理：`python code/practice1_answer.py`、`python code/practice2_answer.py`。

## 提醒

- 需要 Python 3.10 或更高版本，只用标准库，不用装任何包。
- 所有轨迹都是模拟数据，不连接真实模型、真实文件系统。
- 「可疑」只表示这一条轨迹触发了工具白名单规则，不代表已经证明它是恶意投毒。

## 遇到问题

联系付于文，QQ 3344501916，备注来意。
