#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""memory_provenance_lab.py —— Agent 记忆来源归属小实验（教学用，数据全部虚构）

用法：
    python memory_provenance_lab.py --build     生成 memory_store.json + truth.json
    python memory_provenance_lab.py --verify    两种判定器各判定一遍，写 results.csv
    python memory_provenance_lab.py --all       先 build 再 verify

为什么把文件拆成两个：
    memory_store.json  记忆库。只有来源密钥和记忆本身，验证器只能读这个文件。
    truth.json         评测端真值。记录真实来源集合与扰动前应有句数，判定函数不许读。
    分开保存不是形式主义：一旦验证器能读到真值，任何"错误归属"都会被随手修正，
    实验就不再观察系统的判断能力，而是在观察你自己的答案。

锚点规则：
    anchor(key, text) = HMAC-SHA256(key, text) 的前 8 位
    每个句子带一个锚点；用哪把来源密钥算得出来，这句话就属于哪个来源。
"""

import argparse
import csv
import hashlib
import hmac
import json
import os

ANCHOR_LEN = 8
KEYS = {"U": "demo-key-user-001", "T": "demo-key-tool-002"}

# 来源 U：用户在对话里自己说的话
U_SENT = [
    "我不吃香菜",
    "我房租每月 2800 元",
    "我通勤坐 9 号线",
    "我周三晚上有瑜伽课",
    "我习惯睡前记账",
    "我每月餐费大约 1200 元",
    "我不喝含糖饮料",
    "我周末一般在家做饭",
]

# 来源 T：记账工具返回的账单记录
T_SENT = [
    "上月餐饮支出 1180 元",
    "上月交通支出 96 元",
    "上月房租支出 2800 元",
    "上月超市支出 430 元",
    "上月外卖 17 单",
    "上月话费 59 元",
    "上月水电 88 元",
    "上月总支出 4610 元",
]

# 三条固定 QA，用来量"这段记忆还有没有使用价值"
QA = [
    ("我每月餐费大概多少？", ["1200", "1180"]),
    ("我房租是多少？", ["2800"]),
    ("我通勤坐哪条地铁线？", ["9号线", "9 号线"]),
]

CAT_LABEL = {"normal": "正常", "attack": "攻击", "missing": "证据缺失"}


def anchor(key, text):
    return hmac.new(key.encode("utf-8"), text.encode("utf-8"), hashlib.sha256).hexdigest()[:ANCHOR_LEN]


def sent(text, source=None, mode="ok", old_text=None):
    """造一个句子。

    mode="ok"     正常签名：anchor(source, text)
    mode="null"   没有锚点
    mode="fake"   伪造锚点（随便一个十六进制串）
    mode="stale"  锚点是旧的：anchor(source, old_text)，对不上现在的 text
    """
    item = {"text": text}
    if mode == "ok":
        item["anchor"] = anchor(KEYS[source], text)
    elif mode == "null":
        item["anchor"] = None
    elif mode == "fake":
        item["anchor"] = "deadbeef"
    elif mode == "stale":
        item["anchor"] = anchor(KEYS[source], old_text)
    else:
        raise ValueError(mode)
    return item


def qa_answerable(record):
    """这段记忆能答出几条固定 QA（只查关键词，够用就行）"""
    texts = " ".join(s["text"] for s in record["sentences"])
    return sum(1 for _, kws in QA if any(k in texts for k in kws))


def build(store_path, truth_path):
    records, truths = [], []

    def add(rid, category, claim, sentences, truth_sources, note, expected=None):
        rec = {"id": rid, "category": category, "claim": claim,
               "sentences": sentences, "note": note}
        records.append(rec)
        truths.append({
            "id": rid,
            "sources": truth_sources,
            "expected_sentences": expected if expected else len(sentences),
            "note": note,
        })

    # ---- 正常样本 ----
    add("N1", "normal", ["U"],
        [sent(U_SENT[0], "U"), sent(U_SENT[1], "U"), sent(U_SENT[2], "U"), sent(U_SENT[5], "U")],
        ["U"], "单来源，4 句，锚点完整")
    add("N2", "normal", ["T"],
        [sent(T_SENT[0], "T"), sent(T_SENT[2], "T"), sent(T_SENT[4], "T"), sent(T_SENT[5], "T")],
        ["T"], "单来源，4 句，锚点完整")
    add("N3", "normal", ["U", "T"],
        [sent(U_SENT[0], "U"), sent(U_SENT[1], "U"), sent(T_SENT[0], "T"), sent(T_SENT[2], "T")],
        ["U", "T"], "合法混合：两个来源各 2 句，锚点都保留")
    add("N4", "normal", ["U"],
        [sent(U_SENT[0], "U"), sent(U_SENT[1], "U"), sent(U_SENT[2], "U"),
         sent("我每月餐费大约 1300 元", "U")],
        ["U"], "合法更新：内容改过，锚点跟着重算（注意它和 A3 的区别）")
    add("N5", "normal", ["U"],
        [sent(U_SENT[2], "U"), sent(U_SENT[3], "U"), sent(U_SENT[4], "U")],
        ["U"], "单来源，3 句，锚点完整")

    # ---- 攻击 / 干扰样本 ----
    add("A1", "attack", ["U"],
        [sent(U_SENT[0], "U"), sent(U_SENT[1], "U"), sent(U_SENT[2], "U"), sent(U_SENT[5], "U"),
         sent(T_SENT[0], "T")],
        ["U", "T"], "片段移植：只搬来 1 句工具的话，锚点保留（最容易查出来的一种）")
    add("A2", "attack", ["U"],
        [sent(U_SENT[0], "U"), sent(U_SENT[1], "U"), sent(U_SENT[2], "U"), sent(U_SENT[5], "U"),
         sent(T_SENT[0], mode="null")],
        ["U", "T"], "片段移植 + 删锚点：搬来 1 句，把它自己的锚点抹掉")
    add("A3", "attack", ["U"],
        [sent(U_SENT[0], "U"), sent(U_SENT[1], "U"), sent(U_SENT[2], "U"),
         sent(T_SENT[0], "U", mode="stale", old_text=U_SENT[5])],
        ["U", "T"], "内容替换：第 4 句换成工具的话，锚点还是旧内容的（没重算）")
    add("A5", "attack", ["U"],
        [sent(U_SENT[0], "U"), sent(U_SENT[1], "U"), sent(U_SENT[2], "U"),
         sent(T_SENT[0], mode="fake")],
        ["U", "T"], "伪造锚点：搬来 1 句，再给它配一个随便写的 8 位锚点")

    # ---- 证据缺失样本 ----
    add("A4", "missing", ["U"],
        [sent(U_SENT[0], mode="null"), sent(U_SENT[1], mode="null"),
         sent(U_SENT[2], mode="null"), sent(U_SENT[5], mode="null")],
        ["U"], "锚点全丢：内容还在，来源证据一点不剩（这是证据缺失，不是伪造成功）")

    # ---- 截断样本 ----
    add("A6", "attack", ["U"],
        [sent(U_SENT[0], "U"), sent(U_SENT[1], "U")],
        ["U"], "删除：原本 4 句，删掉 2 句，剩下的锚点完好（验证器看不出少了东西）",
        expected=4)

    store = {
        "说明": "记忆库。验证器只能读这个文件，不许读 truth.json。",
        "keys": KEYS,
        "records": records,
    }
    with open(store_path, "w", encoding="utf-8") as f:
        json.dump(store, f, ensure_ascii=False, indent=2)
    with open(truth_path, "w", encoding="utf-8") as f:
        json.dump({"说明": "评测端真值，只在打分时读", "records": truths},
                  f, ensure_ascii=False, indent=2)
    print(f"已生成 {store_path}（{len(records)} 条记忆）与 {truth_path}")


def verify_record(rec, mode, keys=None):
    """判定一条记忆。mode: strict（严格模式）/ majority（多数模式）

    返回 (判定, 识别出的来源, 命中句数)。注意这里的覆盖只按这一条记录自己的句子算，
    "原本应该有几句"只有 truth.json 知道 —— 所以删句这件事，验证器本身看不见。
    """
    if keys is None:
        keys = KEYS
    matched = {source: 0 for source in keys}
    unknown = 0
    for s in rec["sentences"]:
        a = s.get("anchor")
        hit = None
        if a:
            for name, key in keys.items():
                if anchor(key, s["text"]) == a:
                    hit = name
                    break
        if hit is None:
            unknown += 1
        else:
            matched[hit] += 1

    sources = sorted(k for k, v in matched.items() if v > 0)
    claim = sorted(rec["claim"])
    total = len(rec["sentences"]) or 1
    hit_n = sum(matched.values())

    if mode == "strict":
        if not sources:
            return "unknown", [], hit_n
        if unknown > 0 or set(sources) != set(claim):
            return "partial", sources, hit_n
        return "attributed", sources, hit_n

    # majority：谁占得多就整体判给谁，占比 ≥ 50% 就算过；平票取字母序较大的来源。
    if not sources:
        return "unknown", [], hit_n
    top = max(sources, key=lambda k: (matched[k], k))
    if matched[top] / total >= 0.5:
        return "attributed", [top], hit_n
    return "partial", sources, hit_n


def verify(store_path, truth_path, csv_path):
    store = json.load(open(store_path, encoding="utf-8"))
    truth = {r["id"]: r for r in json.load(open(truth_path, encoding="utf-8"))["records"]}

    rows = []
    for rec in store["records"]:
        t = truth[rec["id"]]
        sr, ss, sh = verify_record(rec, "strict", store["keys"])
        mr, ms, mh = verify_record(rec, "majority", store["keys"])
        rows.append({
            "id": rec["id"],
            "类别": CAT_LABEL[rec["category"]],
            "申报来源": "+".join(sorted(rec["claim"])) or "-",
            "真值来源": "+".join(sorted(t["sources"])) or "-",
            "句子数": len(rec["sentences"]),
            "真值应有句数": t["expected_sentences"],
            "严格_判定": sr,
            "严格_来源": "+".join(ss) or "-",
            "严格_覆盖": f"{sh / t['expected_sentences']:.2f}",
            "多数_判定": mr,
            "多数_来源": "+".join(ms) or "-",
            "多数_覆盖": f"{mh / t['expected_sentences']:.2f}",
            "QA可答": qa_answerable(rec),
            "扰动说明": rec.get("note", ""),
        })

    with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print("\n逐条判定（完整结果见 results.csv）")
    print("ID | 类别 | 申报 | 真值 | 严格模式 | 严格覆盖 | 多数模式 | 多数覆盖 | QA")
    for r in rows:
        print(f"{r['id']} | {r['类别']} | {r['申报来源']} | {r['真值来源']} | "
              f"{r['严格_判定']}({r['严格_来源']}) | {r['严格_覆盖']} | "
              f"{r['多数_判定']}({r['多数_来源']}) | {r['多数_覆盖']} | {r['QA可答']}/3")

    def pct(a, b):
        return f"{a}/{b} ({a / b * 100:.0f}%)" if b else "0/0"

    print("\n汇总指标")
    for mode, label, pfx in (("strict", "严格模式", "严格"), ("majority", "多数模式", "多数")):
        vk, sk, ck = f"{pfx}_判定", f"{pfx}_来源", f"{pfx}_覆盖"
        atk = [r for r in rows if r["类别"] == "攻击"]
        nor = [r for r in rows if r["类别"] == "正常"]
        err = sum(1 for r in atk if r[vk] == "attributed" and r[sk] != r["真值来源"])
        bad_norm = sum(1 for r in nor if r[vk] == "attributed" and r[sk] != r["真值来源"])
        over = sum(1 for r in nor if r[vk] != "attributed")
        unk = sum(1 for r in rows if r[vk] == "unknown")
        thin = sum(1 for r in rows if r[vk] == "attributed" and float(r[ck]) < 1.0)
        print(f"[{label}] 攻击样本错误接受率 {pct(err, len(atk))} | "
              f"正常样本错误归属率 {pct(bad_norm, len(nor))} | "
              f"正常样本过度拒绝率 {pct(over, len(nor))} | "
              f"未知比例 {pct(unk, len(rows))} | "
              f"证据不足仍被接受 {pct(thin, len(rows))}")

    print("\n使用价值（3 条固定 QA，只看这段记忆还能答出几题）")
    for cat in ("normal", "attack", "missing"):
        sub = [r for r in rows if r["类别"] == CAT_LABEL[cat]]
        if sub:
            avg = sum(r["QA可答"] for r in sub) / len(sub)
            print(f"  {CAT_LABEL[cat]} {len(sub)} 条：平均 {avg:.2f}/3")

    print(f"\n已写出 {csv_path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", action="store_true")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--store", default="memory_store.json")
    ap.add_argument("--truth", default="truth.json")
    ap.add_argument("--out", default="results.csv")
    ap.add_argument("--workdir", default=".")
    args = ap.parse_args()

    os.chdir(args.workdir)
    if args.all or args.build:
        build(args.store, args.truth)
    if args.all or args.verify:
        verify(args.store, args.truth, args.out)


if __name__ == "__main__":
    main()
